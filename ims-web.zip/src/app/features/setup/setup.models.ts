export interface InitializeSystemRequest {
  email: string;
  userName: string;
  password: string;
}
