import { environment } from '../../../environments/environment';
export const API_BASE = environment.apiBaseUrl;
